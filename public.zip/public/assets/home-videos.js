const homeVideos = [
  /* {
    id: "1efQb8OSqZcCogutFBOCR7Y8TWanFPkgU",
    type: "video/mp4",
    title: "Black",
  },
  {
    id: "1hziiOLoOkOlxHogG_CQmBvdvrb9TB8s9",
    type: "video/mp4",
    title: "hey",
  },
  {
    id: "1nMSK60J2DTNYQoevdBMMbOyxBzg9nMz5",
    type: "video/mp4",
    title: "london",
  }, */
];

/* <video id="video-google-drive" poster="https://drive.google.com/thumbnail?id=1SV001my3nyU22DDBkcLR-UYA0l_jV1C8" preload="auto" controls>
    <source src="https://drive.google.com/uc?id=1SV001my3nyU22DDBkcLR-UYA0l_jV1C8" type="video/mp4">    
</video> */
// Nota sobre Google Drive:
// Reemplaza las URLs de ejemplo (como https://via.placeholder.com/...)
// con las URLs *directas y públicas* de tus imágenes de Google Drive si logras obtenerlas.
// Como se mencionó antes, esto puede ser complicado y poco fiable.
// La URL debería apuntar directamente al archivo de imagen, no a la página de visualización de Drive.
// Ejemplo (hypothetical and likely won't work reliably):
// "url": "https://drive.google.com/uc?export=download&id=TU_ID_DEL_ARCHIVO_DE_DRIVE"
// O si obtuviste una URL directa de otra manera:
// "url": "https://lh3.googleusercontent.com/d/TU_OTRA_URL_DIRECTA_SI_EXISTE=sXXXX"
