const logosImagesData = [
  /*  {
    url: "https://drive.google.com/thumbnail?id=1-5Lj2NcD_7LFXqpZux8OwBrmCXEdDb-x&sz=w200",
    alt: "Hey",
    urlProducts: [
      {
        url: "https://drive.google.com/thumbnail?id=1ONnkPZbIk34J1cLritn-6bS7o3ByHQUC&sz=w200",
        alt: "Hey",
      },
    ],
  },
  {
    url: "https://drive.google.com/thumbnail?id=1P6Bl9p9UfJVjD0Pdqdz6ZmRnRn0mGmdP&sz=w200",
    alt: "London cats",
    urlProducts: [
      {
        url: "https://drive.google.com/thumbnail?id=1ONnkPZbIk34J1cLritn-6bS7o3ByHQUC&sz=w200",
        alt: "Pipicat Premium",
      },
    ],
  },
  {
    url: "https://drive.google.com/thumbnail?id=1pzM4Iet5heRxT7H1GhB1L7V8tdYkKTFM&sz=w200",
    alt: "Gatuna",
    urlProducts: [
      {
        url: "https://drive.google.com/thumbnail?id=1ONnkPZbIk34J1cLritn-6bS7o3ByHQUC&sz=w200",
        alt: "Pipicat Premium",
      },
    ],
  },
  {
    url: "https://drive.google.com/thumbnail?id=1-9TdJVoOBKkl3Ky93eCjHC_ENeHeNtiv&sz=w200",
    alt: "Pipicat",
    urlProducts: [
      {
        url: "https://drive.google.com/thumbnail?id=1ONnkPZbIk34J1cLritn-6bS7o3ByHQUC&sz=w200",
        alt: "Pipicat Premium",
      },
      {
        url: "https://drive.google.com/thumbnail?id=1GNjyJ-NM2JxDcDHeSjn_9_fhp7GatVEt&sz=w200",
        alt: "Pipicat Super Premium",
      },
    ],
  },
  {
    url: "https://drive.google.com/thumbnail?id=1-5Lj2NcD_7LFXqpZux8OwBrmCXEdDb-x&sz=w200",
    alt: "Hey",
  },
  {
    url: "https://drive.google.com/thumbnail?id=1P6Bl9p9UfJVjD0Pdqdz6ZmRnRn0mGmdP&sz=w200",
    alt: "London cats",
  },
  {
    url: "https://drive.google.com/thumbnail?id=1pzM4Iet5heRxT7H1GhB1L7V8tdYkKTFM&sz=w200",
    alt: "Gatuna",
  },
  {
    url: "https://drive.google.com/thumbnail?id=1-9TdJVoOBKkl3Ky93eCjHC_ENeHeNtiv&sz=w200",
    alt: "Pipicat",
  }, */
];
