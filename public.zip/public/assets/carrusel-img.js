/* const carouselImagesData = [
  {
    url: "https://drive.google.com/thumbnail?id=1y2CFFQh6uecQFlSsWk6qIojgfvapdlQP&sz=w1440",
    alt: "London Cats",
    type: "black",
  },
  {
    url: "https://drive.google.com/thumbnail?id=1tVenzxD71zebWe7bMaJ_mk9IaEhbV1-b&sz=w1440",
    alt: "London Cats",
    type: "basica",
  },
  {
    url: "https://drive.google.com/thumbnail?id=1toQGWfNSJg7T5UDmprFZtlULQbwvvaex&sz=w1440",

    alt: "Hey!",
    type: "basica",
  },
  {
    url: "https://drive.google.com/thumbnail?id=1iDQ79msml1zqEzxsxO_Himx9opstUgaH&sz=w1440",

    alt: "Gatuna",
    type: "premium",
  },
  {
    url: "https://drive.google.com/thumbnail?id=1OkhlpVQNfZUZas6qdJZcl66rZg_wGbN1&sz=w1440",

    alt: "Pipicat ",
    type: "super",
  },
  {
    url: "https://drive.google.com/thumbnail?id=14uhu0iD9cOTqOQXQkG-3xxiMJ08yZvS5&sz=w1440",

    alt: "Pipicat",
    type: "premium",
  },
]; */

// Nota sobre Google Drive:
// Reemplaza las URLs de ejemplo (como https://via.placeholder.com/...)
// con las URLs *directas y públicas* de tus imágenes de Google Drive si logras obtenerlas.
// Como se mencionó antes, esto puede ser complicado y poco fiable.
// La URL debería apuntar directamente al archivo de imagen, no a la página de visualización de Drive.
// Ejemplo (hypothetical and likely won't work reliably):
// "url": "https://drive.google.com/uc?export=download&id=TU_ID_DEL_ARCHIVO_DE_DRIVE"
// O si obtuviste una URL directa de otra manera:
// "url": "https://lh3.googleusercontent.com/d/TU_OTRA_URL_DIRECTA_SI_EXISTE=sXXXX"
