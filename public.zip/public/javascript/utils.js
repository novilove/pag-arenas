export const routeServer =
  "https://stalwart-faloodeh-22bebe.netlify.app/public/assets/svg";
